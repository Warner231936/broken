package net

type ByteArray struct {
	Buffer   []byte
	position int32
	Size     int32
}

func NewByteArray() *ByteArray {
	return &ByteArray{
		Buffer:   make([]byte, 0),
		position: 0,
		Size:     0,
	}
}

func NewByteArrayFromData(data []byte) *ByteArray {
	buffer := make([]byte, len(data)+16-len(data)%16)
	copy(buffer, data)
	return &ByteArray{
		Buffer:   buffer,
		position: 0,
		Size:     int32(len(data)),
	}
}

func (receiver *ByteArray) setPosition(position int32) {
	receiver.position = position
}

func (receiver *ByteArray) push(b byte) {
	if int32(len(receiver.Buffer)) == receiver.Size {
		oldBuffer := receiver.Buffer
		receiver.Buffer = make([]byte, int32(len(receiver.Buffer)+16))
		copy(receiver.Buffer, oldBuffer)
	}
	receiver.Buffer[receiver.Size] = b
	receiver.Size++
}

func (receiver *ByteArray) writeByte(b byte) {
	receiver.push(b)
}

func (receiver *ByteArray) readByte() byte {
	v := receiver.Buffer[receiver.position]
	receiver.position++
	return v
}

func (receiver *ByteArray) writeChar(c byte) {
	receiver.push(c)
}

func (receiver *ByteArray) readChar() string {
	v := receiver.Buffer[receiver.position]
	receiver.position++
	return string(v)
}

func (receiver *ByteArray) writeShort(s int16) {
	receiver.push(byte(s & 0x00FF))
	receiver.push(byte(s >> 8))
}

func (receiver *ByteArray) readShort() int16 {
	var ret int16 = 0
	ret |= int16(receiver.Buffer[receiver.position] & 0x00FF)
	receiver.position++
	ret |= int16(receiver.Buffer[receiver.position]&0x00FF) << 8
	receiver.position++
	return ret
}

func (receiver *ByteArray) writeInt(i int32) {
	receiver.push(byte(i & 0x000000FF))
	receiver.push(byte((i >> 8) & 0x000000FF))
	receiver.push(byte((i >> 16) & 0x000000FF))
	receiver.push(byte((i >> 24) & 0x000000FF))
}

func (receiver *ByteArray) readInt() int32 {
	var ret int32 = 0
	ret |= int32(receiver.Buffer[receiver.position] & 0xFF)
	receiver.position++
	ret |= int32(receiver.Buffer[receiver.position]&0xFF) << 8
	receiver.position++
	ret |= int32(receiver.Buffer[receiver.position]&0xFF) << 16
	receiver.position++
	ret |= int32(receiver.Buffer[receiver.position]&0xFF) << 24
	receiver.position++
	return ret
}

func (receiver *ByteArray) writeLong(i int64) {
	receiver.push(byte(i & 0x000000FF))
	receiver.push(byte((i >> 8) & 0x000000FF))
	receiver.push(byte((i >> 16) & 0x000000FF))
	receiver.push(byte((i >> 24) & 0x000000FF))
	receiver.push(byte((i >> 32) & 0x000000FF))
	receiver.push(byte((i >> 40) & 0x000000FF))
	receiver.push(byte((i >> 48) & 0x000000FF))
	receiver.push(byte((i >> 56) & 0x000000FF))
}

func (receiver *ByteArray) readLong() int64 {
	var ret int64 = 0
	ret |= int64(receiver.Buffer[receiver.position] & 0xFF)
	receiver.position++
	ret |= int64(receiver.Buffer[receiver.position]&0xFF) << 8
	receiver.position++
	ret |= int64(receiver.Buffer[receiver.position]&0xFF) << 16
	receiver.position++
	ret |= int64(receiver.Buffer[receiver.position]&0xFF) << 24
	receiver.position++
	ret |= int64(receiver.Buffer[receiver.position]&0xFF) << 32
	receiver.position++
	ret |= int64(receiver.Buffer[receiver.position]&0xFF) << 40
	receiver.position++
	ret |= int64(receiver.Buffer[receiver.position]&0xFF) << 48
	receiver.position++
	ret |= int64(receiver.Buffer[receiver.position]&0xFF) << 56
	receiver.position++
	return ret
}

func (receiver *ByteArray) WriteString(s string, slen int32) {
	str := []byte(s)

	if int32(len(receiver.Buffer))-receiver.Size < slen {
		oldBuffer := receiver.Buffer
		receiver.Buffer = make([]byte, int32(len(oldBuffer))+16+slen-slen%16)
		copy(receiver.Buffer, oldBuffer)
	}
	copy(receiver.Buffer[receiver.Size:], str)

	receiver.Size += slen
}

func (receiver *ByteArray) readString(len int32) string {
	myString := string(receiver.Buffer[receiver.position : receiver.position+len])
	receiver.position += len
	return myString
}

func (receiver *ByteArray) writeBoolean(b bool) {
	if b {
		receiver.writeByte(1)
	} else {
		receiver.writeByte(0)
	}
}

func (receiver *ByteArray) readBoolean() bool {
	res := receiver.Buffer[receiver.position]
	receiver.position++
	return res != 0
}

func (receiver *ByteArray) padSize(size int32) {
	xs := size - receiver.Size

	if xs <= 0 {
		return
	}

	if int32(len(receiver.Buffer))-receiver.Size < xs {
		oldBuffer := receiver.Buffer
		receiver.Buffer = make([]byte, int32(len(oldBuffer))+16+xs-xs%16)
		copy(receiver.Buffer, oldBuffer)
	}
	receiver.Size += xs

}
