package net

import (
	"fmt"
	"reflect"
	"tview-example/pkg/msg"
)

type Request interface {
	SetSeqId(int32)
}

func Encode(v Request) (*ByteArray, error) {
	refObjVal := reflect.Indirect(reflect.ValueOf(v))
	buf := NewByteArray()

	var usSize int16
	for i := 0; i < refObjVal.NumField(); i++ {
		structFieldRefObj := refObjVal.Field(i)
		switch structFieldRefObj.Kind() {
		case reflect.Struct:
			ys := structFieldRefObj.Interface().(msg.StringWithLen)
			buf.WriteString(ys.Value, ys.Length)
		case reflect.Int32:
			buf.writeInt(structFieldRefObj.Interface().(int32))
		case reflect.Int16:
			if refObjVal.Type().Field(i).Name == "UsSize" {
				usSize = structFieldRefObj.Interface().(int16)
			}
			shortVal := structFieldRefObj.Interface().(int16)
			buf.writeShort(shortVal)
		case reflect.Int64:
			buf.writeLong(structFieldRefObj.Interface().(int64))
		case reflect.Bool:
			buf.writeBoolean(structFieldRefObj.Interface().(bool))
		case reflect.Uint8:
			buf.writeByte(structFieldRefObj.Interface().(uint8))
		case reflect.Array:
			for j := 0; j < structFieldRefObj.Len(); j++ {
				switch structFieldRefObj.Index(j).Kind() {
				case reflect.Int32:
					buf.writeInt(structFieldRefObj.Index(j).Interface().(int32))
				case reflect.Int16:
					buf.writeShort(structFieldRefObj.Index(j).Interface().(int16))
				case reflect.Int64:
					buf.writeLong(structFieldRefObj.Index(j).Interface().(int64))
				case reflect.Bool:
					buf.writeBoolean(structFieldRefObj.Index(j).Interface().(bool))
				case reflect.Uint8:
					buf.writeByte(structFieldRefObj.Index(j).Interface().(uint8))
				default:
					return nil, fmt.Errorf("encode: unsupported type")
				}

			}

		default:
			return nil, fmt.Errorf("encode: unsupported type")
		}

	}
	if usSize == 0 {
		return nil, fmt.Errorf("encode: usSize is 0")
	}
	buf.padSize(int32(usSize))

	return buf, nil
}

func DecodeToStruct(v any, buf *ByteArray) (err error) {
	vp := reflect.ValueOf(v)
	ve := vp.Elem()
	vt := ve.Type()
	nStructFields := ve.NumField()

	for i := 0; i < nStructFields; i++ {
		fv := ve.Field(i)
		sf := vt.Field(i)
		switch sf.Type.Kind() {
		case reflect.Bool:
			fv.SetBool(buf.readBoolean())
		case reflect.Uint8:
			fv.Set(reflect.ValueOf(buf.readByte()))
		case reflect.Int16:
			fv.Set(reflect.ValueOf(buf.readShort()))
		case reflect.Int32:
			fv.Set(reflect.ValueOf(buf.readInt()))
		case reflect.Int64:
			fv.Set(reflect.ValueOf(buf.readLong()))
		case reflect.Slice:
			// Best solution is to use a slice, since dataLen is not known in advance.
			// DataLen int32
			// Data [](any struct)
			dataLen := ve.FieldByName(sf.Name + "Len").Interface().(int32)
			sliceType := reflect.SliceOf(sf.Type.Elem())
			fv.Set(reflect.MakeSlice(sliceType, int(dataLen), int(dataLen)))
			if sf.Type.Elem().Kind() == reflect.Struct {
				var j int32
				for j = 0; j < dataLen; j++ {
					fv.Index(int(j)).Set(reflect.New(sf.Type.Elem()).Elem())
					err = DecodeToStruct(fv.Index(int(j)).Addr().Interface(), buf)
				}
			} else if sf.Type.Elem().Kind() == reflect.Int32 {
				//TODO: use another function to read int32 slice
				// decodeToValue
				var j int32
				for j = 0; j < dataLen; j++ {
					fv.Index(int(j)).Set(reflect.ValueOf(buf.readInt()))
				}
			}

		case reflect.Array:
			// Solution for now is to use a set array with a set length since its known beforehand
			// Data [](any struct)
			dataLen := sf.Type.Len()
			if sf.Type.Elem().Kind() == reflect.Struct {
				for j := 0; j < dataLen; j++ {
					xs := fv.Index(j).Addr().Interface()
					if buf.Size > buf.position {
						err = DecodeToStruct(xs, buf)
						fv.Index(j).Set(reflect.Indirect(reflect.ValueOf(xs)))
					}

				}
			} else if sf.Type.Elem().Kind() == reflect.Int32 {
				//TODO: use another function to read int32 slice
				// decodeToValue
				for j := 0; j < dataLen; j++ {
					if buf.Size > buf.position {
						fv.Index(j).Set(reflect.ValueOf(buf.readInt()))
					}
				}
			} else if sf.Type.Elem().Kind() == reflect.Int16 {
				//TODO: use another function to read int16 slice
				// decodeToValue
				for j := 0; j < dataLen; j++ {
					if buf.Size > buf.position {
						fv.Index(j).Set(reflect.ValueOf(buf.readShort()))
					}
				}
			}

		case reflect.Struct:
			if sf.Type.Name() == "StringWithLen" {
				sl := fv.Interface().(msg.StringWithLen)
				fv.Set(reflect.ValueOf(msg.StringWithLen{
					Length: sl.Length,
					Value:  buf.readString(sl.Length),
				}))
			}
		}
	}
	return nil
}
