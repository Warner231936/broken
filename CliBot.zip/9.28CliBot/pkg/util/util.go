package util

import (
	"math/rand"
	"time"
)

func SleepRandomMillis(min, max int) {
	randInt := rand.Intn(max-min+1) + min
	time.Sleep(time.Duration(randInt) * time.Millisecond)
}
