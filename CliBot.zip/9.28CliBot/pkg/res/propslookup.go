package res

import (
	"bufio"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

type PropsMap map[int32]string

func (m PropsMap) GetPropsName(propsId int32) string {
	return m[propsId]
}

var PropsMapLookup = make(PropsMap)

func init() {
	pwd, _ := os.Getwd()
	file, err := os.Open(filepath.Join(pwd, "res/props.txt"))
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		lineSplit := strings.Split(line, "=")
		propsId, err := strconv.Atoi(lineSplit[0])
		if err != nil {
			panic(err)
		}
		PropsMapLookup[int32(propsId)] = lineSplit[1]
	}
	if err := scanner.Err(); err != nil {
		log.Fatal(err)
	}

}
