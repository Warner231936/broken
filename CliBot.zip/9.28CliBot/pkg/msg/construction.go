package msg

type TimeQueue struct {
	Type      int32
	SpareTime int32
}

type RespTimeQueue struct {
	UsSize  int16
	UsType  int16
	DataLen int32
	Data    []TimeQueue
}

func NewRespTimeQueue() *RespTimeQueue {
	return &RespTimeQueue{}
}

type ReqGetStorageResource struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
}

func NewReqGetStorageResource(guid int32) *ReqGetStorageResource {
	return &ReqGetStorageResource{
		UsSize: int16(12),
		UsType: int16(ReqGetStorageResourceType),
		SeqId:  0,
		Guid:   guid,
	}
}

func (c *ReqGetStorageResource) SetSeqId(i int32) {
	c.SeqId = i
}

type RespGetStorageResource struct {
	UsSize int16
	UsType int16
	Gas    int32
	Metal  int32
	Money  int32
}

func NewRespGetStorageResource() *RespGetStorageResource {
	return &RespGetStorageResource{}
}
