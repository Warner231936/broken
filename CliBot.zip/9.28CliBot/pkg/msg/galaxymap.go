package msg

const AreaGridX int32 = 10
const AreaGridY int32 = 10
const MaxMapArea int32 = 42
const MaxMapAreaGrid = AreaGridY * MaxMapArea
const MaxMapAreas = 210 * 3600

type ReqGalaxy struct {
	UsSize      int16
	UsType      int16
	SeqId       int32
	Guid        int32
	GalaxyMapId int32
	GalaxyId    int32
}

func NewReqGalaxy(guid int32, galaxyId int32) *ReqGalaxy {
	return &ReqGalaxy{
		UsSize:      20,
		UsType:      int16(ReqGalaxyType),
		SeqId:       0,
		Guid:        guid,
		GalaxyMapId: 0,
		GalaxyId:    galaxyId,
	}
}

func (c *ReqGalaxy) SetSeqId(i int32) {
	c.SeqId = i
}

type ReqMapArea struct {
	UsSize      int16
	UsType      int16
	SeqId       int32
	Guid        int32
	GalaxyMapId int32
	RegionId    [16]int32
}

func (c *ReqMapArea) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqMapArea(guid int32) *ReqMapArea {
	return &ReqMapArea{
		UsSize: 80,
		UsType: int16(ReqMapAreaType),
		Guid:   guid,
	}
}

func (c *ReqMapArea) CalculateGalaxyMap2(galaxyId int32) {
	var loc8 int32 = 0
	loc3 := getStarArea(galaxyId) - 42 - 1
	var loc5 = make([]int32, 0, 16)
	for loc6 := int32(0); loc6 < 4; loc6++ {
		for loc8 = int32(0); loc8 < 4; loc8++ {
			loc4 := loc3 + loc8 + loc6*MaxMapArea
			if loc4 > -1 && loc4 < MaxMapAreas {
				loc5 = append(loc5, loc4)
			}
		}
	}
	copy(c.RegionId[:], loc5)

}

func getStarArea(galaxyId int32) int32 {
	loc3 := galaxyId % MaxMapAreaGrid / AreaGridY
	loc2 := (galaxyId / MaxMapAreaGrid) / AreaGridX * MaxMapArea
	return loc3 + loc2
}
