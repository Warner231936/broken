package msg

type RespNewEmailNotice struct {
	UsSize    int16
	UsType    int16
	ErrorCode int32
}

func NewRespNewEmailNotice() *RespNewEmailNotice {
	return &RespNewEmailNotice{}
}

type EmailInfo struct {
	Title         StringWithLen
	Name          StringWithLen
	DateTime      int64
	SrcUserId     int64
	SrcGuid       int32
	AutoId        int32
	FightGalaxyId int32
	Type          byte
	ReadFlag      byte
	GoodFlag      byte
	TitleType     byte
}

func NewEmailInfo() *EmailInfo {
	return &EmailInfo{
		Title: StringWithLen{
			Length: int32(MaxName),
		},
		Name: StringWithLen{
			Length: int32(MaxName),
		},
	}
}

type ReqEmailInfo struct {
	UsSize   int16
	UsType   int16
	SeqId    int32
	Guid     int32
	PageId   int32
	Type     byte
	ReadFlag byte
}

func (c *ReqEmailInfo) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqEmailInfo(guid, pageId int32) *ReqEmailInfo {
	return &ReqEmailInfo{
		UsSize:   int16(18),
		UsType:   int16(ReqEmailInfoType),
		SeqId:    0,
		Guid:     guid,
		PageId:   pageId,
		Type:     255,
		ReadFlag: 255,
	}
}

type RespEmailInfo struct {
	UsSize  int16
	UsType  int16
	DataLen int32
	Data    [9]EmailInfo
}

func NewRespEmailInfo() *RespEmailInfo {
	resp := RespEmailInfo{}
	for i := 0; i < len(resp.Data); i++ {
		resp.Data[i] = *NewEmailInfo()
	}
	return &resp
}

type ReqReadEmail struct {
	UsSize    int16
	UsType    int16
	SeqId     int32
	Guid      int32
	AutoId    int32
	FightFlag int32
}

func (c *ReqReadEmail) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqReadEmail(guid int32, autoId int32) *ReqReadEmail {
	return &ReqReadEmail{
		UsSize:    int16(20),
		UsType:    int16(ReqReadEmailType),
		SeqId:     0,
		Guid:      guid,
		AutoId:    autoId,
		FightFlag: 0,
	}
}

type AttachedProp struct {
	Id      int32
	Num     int32
	LockNum int16
	BodyId  int16
}

func NewAttachedProp() *AttachedProp {
	return &AttachedProp{}
}

type RespReadEmail struct {
	UsSize  int16
	UsType  int16
	AutoId  int32
	DataLen int32
	Content StringWithLen
	Data    [100]AttachedProp
}

func NewRespReadEmail() *RespReadEmail {
	resp := RespReadEmail{}
	resp.Content = StringWithLen{
		Length: int32(512),
	}
	for i := 0; i < len(resp.Data); i++ {
		resp.Data[i] = *NewAttachedProp()
	}
	return &resp
}

type ReqEmailGoods struct {
	UsSize  int16
	UsType  int16
	SeqId   int32
	Guid    int32
	AutoId  int32
	PropsId int32
}

func (c *ReqEmailGoods) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqEmailGoods(guid int32, autoId int32) *ReqEmailGoods {
	return &ReqEmailGoods{
		UsSize:  int16(20),
		UsType:  int16(ReqEmailGoodsType),
		SeqId:   0,
		Guid:    guid,
		AutoId:  autoId,
		PropsId: -1,
	}
}

type RespEmailGoods struct {
	UsSize  int16
	UsType  int16
	AutoId  int32
	PropsId int32
}

func NewRespEmailGoods() *RespEmailGoods {
	return &RespEmailGoods{}
}

type ReqDeleteEmail struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
	AutoId int32
}

func (c *ReqDeleteEmail) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqDeleteEmail(guid int32, autoId int32) *ReqDeleteEmail {
	return &ReqDeleteEmail{
		UsSize: int16(16),
		UsType: int16(ReqDeleteEmailType),
		Guid:   guid,
		AutoId: autoId,
	}
}
