package msg

type ReqEcType struct {
	UsSize       int16
	UsType       int16
	SeqId        int32
	Guid         int32
	EcTypeId     int16
	GateId       byte
	DataLen      byte // how many fleets to send
	ShipTeamId   [60]int32
	PassKey      int32
	RoomId       int32
	JoinFlag     byte
	Activity     byte
	PropsId      int16
	CapturePlace byte
	Reserve      byte
}

func NewReqEcType() *ReqEcType {
	return &ReqEcType{
		UsSize:  int16(270),
		UsType:  int16(ReqEcTypeType),
		SeqId:   0,
		PassKey: -1,
		RoomId:  -1,
	}
}

func (c *ReqEcType) SetSeqId(i int32) {
	c.SeqId = i
}

type RespEcTypeState struct {
	UsSize   int16
	UsType   int16
	EcTypeId int16
	GateId   int16
	State    byte
}

func NewRespEcTypeState() *RespEcTypeState {
	return &RespEcTypeState{}
}

type RespFightResult struct {
	UsSize int16
	UsType int16
}

func NewRespFightResult() *RespFightResult {
	return &RespFightResult{}
}

type RespFightGalaxyBegin struct {
	UsSize        int16
	UsType        int16
	GalaxyMapId   int32
	GalaxyId      int32
	Type          int32
	PirateLevelId int32
	ConsortiaId   int32
	ConsortiaName StringWithLen
}

func NewRespFightGalaxyBegin() *RespFightGalaxyBegin {
	return &RespFightGalaxyBegin{
		ConsortiaName: StringWithLen{
			Length: 32,
		},
	}
}
