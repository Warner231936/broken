package msg

type RespJumpShipTeamNotice struct {
	UsSize int16
	UsType int16
	Type   int32
}

func NewRespJumpShipTeamNotice() *RespJumpShipTeamNotice {
	return &RespJumpShipTeamNotice{}
}
