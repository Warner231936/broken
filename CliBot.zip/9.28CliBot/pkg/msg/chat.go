package msg

type ChatMessage struct {
	UsSize      int16
	UsType      int16
	SeqId       int32
	SrcUserId   int64
	ObjUserId   int64
	Guid        int32
	ObjGuid     int32
	Type        int16
	SpecialType int16
	PropsId     int32
	Corp        StringWithLen
	Acronym     int32
	Rank        int32
	Name        StringWithLen
	ToName      StringWithLen
	Buffer      StringWithLen
}

func NewChatMessage() *ChatMessage {
	return &ChatMessage{
		UsSize: 570,
		UsType: int16(ChatMessageType),
		Corp: StringWithLen{
			Length: int32(64 * 2),
		},
		Name: StringWithLen{
			Length: int32(MaxName * 2),
		},
		ToName: StringWithLen{
			Length: int32(MaxName * 2),
		},
		Buffer: StringWithLen{
			Length: int32(MaxChatMessage * 2),
		},
	}
}

type RespGalaxyBroadcast struct {
	UsSize int16
	UsType int16
	Guid   int32
	UserId int64
	Name   StringWithLen
	Type   int32
}

func NewRespGalaxyBroadCast() *RespGalaxyBroadcast {
	return &RespGalaxyBroadcast{
		Name: StringWithLen{
			Length: int32(MaxName),
		},
	}
}

type ReqUserInfo struct {
	UsSize      int16
	UsType      int16
	SeqId       int32
	Guid        int32
	ObjGuid     int32
	ObjGalaxyId int32
	Reserve     int32
	UserId      int64
	UserName    StringWithLen
}

func NewReqUserInfo(guid int32, objGuid int32, objGalaxyId int32, reserve int32, userId int64, username string) *ReqUserInfo {
	return &ReqUserInfo{
		UsSize:      int16(32 + MaxName),
		UsType:      int16(ReqUserInfoType),
		SeqId:       0,
		Guid:        guid,
		ObjGuid:     objGuid,
		ObjGalaxyId: objGalaxyId,
		Reserve:     reserve,
		UserId:      userId,
		UserName: StringWithLen{
			Length: int32(MaxName),
			Value:  username,
		},
	}
}

func (c *ReqUserInfo) SetSeqId(i int32) {
	c.SeqId = i
}

type RespUserInfo struct {
	UsSize                int16
	UsType                int16
	SeqId                 int32
	Guid                  int32
	UserId                int64
	UserName              StringWithLen
	Consortia             StringWithLen
	rankId                int32
	posX                  int32
	posY                  int32
	peaceTime             int32
	GalaxyId              int32
	SpaceLevel            byte
	CityLevel             byte
	usLevelId             byte
	usMatchLevel          byte
	passMaxEctypt         int32
	ConsortiaId           int32
	PassInsertFlagTime    int32
	InsertFlagConsortiaId int32
	InsertFlagConsortia   StringWithLen
}

func NewRespUserInfo() *RespUserInfo {
	return &RespUserInfo{
		UsType: int16(RespUserInfoType),
		UserName: StringWithLen{
			Length: int32(MaxName),
		},
		Consortia: StringWithLen{
			Length: int32(MaxName),
		},
		InsertFlagConsortia: StringWithLen{
			Length: int32(MaxName),
		},
	}
}
