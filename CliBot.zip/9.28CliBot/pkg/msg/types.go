package msg

const (
	MapRange                            uint16 = 420
	CommanderZJCount                    uint16 = 9
	MaxName                             uint16 = 32
	MaxMemo                             uint16 = 256
	ValidateCodeLength                  uint16 = 25
	SessionKeyLength                    uint16 = 128
	MaxGameServerList                   uint16 = 60
	MaxBuilding                         uint16 = 200
	MaxChatMessage                      uint16 = 128
	ClientLogInToL                      uint16 = 502
	ClientLogInToG                      uint16 = 503
	LogInServerValidate                 uint16 = 504
	GameServerLogInResp                 uint16 = 505
	RoleInfoType                        uint16 = 1007
	ReqPlayerInfoType                   uint16 = 1017
	RespPropsInfoType                   uint16 = 1054
	RespMapBlockType                    uint16 = 1061
	RespGalaxyBroadcastType             uint16 = 1113
	RespTechInfoType                    uint16 = 1212
	ReqPlayerResourceType               uint16 = 1213
	RespPlayerResourceType              uint16 = 1214
	RespEcTypePassType                  uint16 = 1436
	RespCommanderBaseInfoType           uint16 = 1514
	ChatMessageType                     uint16 = 1600
	ReqUserInfoType                     uint16 = 1623
	RespUserInfoType                    uint16 = 1624
	RespCustomMoreInfoType              uint16 = 5001
	RespCustomConfigurationType         uint16 = 5002
	RespOnlineAwardType                 uint16 = 1092
	ReqGetOnlineAwardType               uint16 = 1093
	RespGetOnlineAwardType              uint16 = 1094
	ReqEcTypeType                       uint16 = 1134
	RespEcTypeStateType                 uint16 = 1135
	ReqUsePropsType                     uint16 = 1055
	RespUsePropsType                    uint16 = 1056
	ReqCommanderInfoType                uint16 = 1506
	RespCommanderInfoType               uint16 = 1507
	RespTimeQueueType                   uint16 = 1225
	RespNewEmailNoticeType              uint16 = 1622
	RespShipCreatingCompleteType        uint16 = 1315
	ReqJumpGalaxyShipType               uint16 = 1357
	RespJumpGalaxyShipType              uint16 = 1358
	ReqGetStorageResourceType           uint16 = 1232
	RespGetStorageResourceType          uint16 = 1233
	ReqGainLotteryType                  uint16 = 1082
	RespGainLotteryType                 uint16 = 1083
	ReqLoadShipTeamAllType              uint16 = 1351
	RespLoadShipTeamAllType             uint16 = 1352
	ReqLoadShipTeamType                 uint16 = 1328
	RespLoadShipTeamType                uint16 = 1329
	ReqEmailInfoType                    uint16 = 1608
	RespEmailInfoType                   uint16 = 1609
	ReqDeleteEmailType                  uint16 = 1610
	ReqReadEmailType                    uint16 = 1611
	RespReadEmailType                   uint16 = 1612
	ReqEmailGoodsType                   uint16 = 1613
	RespEmailGoodsType                  uint16 = 1614
	RespFightResultType                 uint16 = 1415
	RespJumpShipTeamNoticeType          uint16 = 1445
	ReqTechUpgradeInfoType              uint16 = 1215
	ReqTaskInfoType                     uint16 = 1064
	ReqGalaxyType                       uint16 = 1100
	ReqMapAreaType                      uint16 = 1250
	ReqStorageResourceType              uint16 = 1236
	FightGalaxyBegin                    uint16 = 1133
	RespUnionCommanderCardBroadcastType uint16 = 1526
	ReqTradeInfoType                    uint16 = 1756
	RespTradeInfoType                   uint16 = 1757
	ReqBuyTradeGoodsType                uint16 = 1758
	RespBuyTradeGoodsType               uint16 = 1759
)

type ResponseSwitch struct {
	commands map[uint16]any
}

func NewSwitch() ResponseSwitch {
	s := ResponseSwitch{}
	s.commands = map[uint16]any{
		GameServerLogInResp:                 NewGameServerLoginResp(),
		LogInServerValidate:                 NewLoginServerValidate(),
		RoleInfoType:                        NewRoleInfo(),
		ChatMessageType:                     NewChatMessage(),
		RespGalaxyBroadcastType:             NewRespGalaxyBroadCast(),
		RespUserInfoType:                    NewRespUserInfo(),
		RespCustomMoreInfoType:              NewRespCustomMoreInfo(),
		RespCustomConfigurationType:         NewRespCustomConfiguration(),
		RespMapBlockType:                    NewRespMapBlock(),
		RespPlayerResourceType:              NewRespPlayerResource(),
		RespEcTypePassType:                  NewRespEcTypePass(),
		RespCommanderBaseInfoType:           NewRespCommanderBaseInfo(),
		RespOnlineAwardType:                 NewRespOnlineAward(),
		RespGetOnlineAwardType:              NewRespGetOnlineAward(),
		RespEcTypeStateType:                 NewRespEcTypeState(),
		RespPropsInfoType:                   NewRespPropsInfo(),
		RespUsePropsType:                    NewRespUseProps(),
		RespTimeQueueType:                   NewRespTimeQueue(),
		RespCommanderInfoType:               NewRespCommanderInfo(),
		RespNewEmailNoticeType:              NewRespNewEmailNotice(),
		RespShipCreatingCompleteType:        NewRespShipCreatingComplete(),
		RespJumpGalaxyShipType:              NewRespJumpGalaxyShip(),
		RespGetStorageResourceType:          NewRespGetStorageResource(),
		RespGainLotteryType:                 NewRespGainLottery(),
		RespLoadShipTeamAllType:             NewRespLoadShipTeamAll(),
		RespLoadShipTeamType:                NewRespLoadShipTeam(),
		RespEmailInfoType:                   NewRespEmailInfo(),
		RespReadEmailType:                   NewRespReadEmail(),
		RespEmailGoodsType:                  NewRespEmailGoods(),
		RespFightResultType:                 NewRespFightResult(),
		RespJumpShipTeamNoticeType:          NewRespJumpShipTeamNotice(),
		FightGalaxyBegin:                    NewRespFightGalaxyBegin(),
		RespUnionCommanderCardBroadcastType: NewRespUnionCommanderCardBroadcast(),
		RespTradeInfoType:                   NewRespTradeInfo(),
		RespBuyTradeGoodsType:               NewRespBuyTradeGoods(),
	}
	return s
}

func (s ResponseSwitch) Get(msgType uint16) any {
	msg, ok := s.commands[msgType]
	if !ok {
		return nil
	}
	return msg
}
