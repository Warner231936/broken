package msg

type Props struct {
	PropsId      int16
	PropsNum     int16
	PropsLockNum int16
	StorageType  byte
	Reserve      byte
}

type RespPropsInfo struct {
	UsSize  int16
	UsType  int16
	DataLen int32
	Data    []Props
}

func NewRespPropsInfo() *RespPropsInfo {
	return &RespPropsInfo{}
}

type ReqUseProps struct {
	UsSize   int16
	UsType   int16
	SeqId    int32
	Guid     int32
	PropsId  int32
	LockFlag int32
	Num      int32
}

func (c *ReqUseProps) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqUseProps(Guid, PropsId, LockFlag, Num int32) *ReqUseProps {
	return &ReqUseProps{
		UsSize:   int16(24),
		UsType:   int16(ReqUsePropsType),
		SeqId:    0,
		Guid:     Guid,
		PropsId:  PropsId,
		LockFlag: LockFlag,
		Num:      Num,
	}
}

type RespUseProps struct {
	UsSize            int16
	UsType            int16
	PropsId           int32
	LockFlag          byte
	ErrorCode         byte
	AwardFlag         byte
	AwardLockFlag     byte
	AwardGas          int32
	AwardMoney        int32
	AwardMetal        int32
	AwardPropsLen     int32
	AwardPropsId      [10]int32
	AwardPropsNum     [10]int32
	MoveHomeFlag      int32
	ToGalaxyMapId     int32
	ToGalaxyId        int32
	Num               int32
	SpValue           int32
	AwardCoins        int32
	AwardBadge        int32
	AwardHonor        int32
	AwardActiveCredit int32
	PirateMoney       int32
}

func NewRespUseProps() *RespUseProps {
	return &RespUseProps{}
}

type ReqGainLottery struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
	Type   int32
}

func (c *ReqGainLottery) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqGainLottery(Guid, Type int32) *ReqGainLottery {
	return &ReqGainLottery{
		UsSize: int16(16),
		UsType: int16(ReqGainLotteryType),
		SeqId:  0,
		Guid:   Guid,
		Type:   Type,
	}
}

type RespGainLottery struct {
	UsSize      int16
	UsType      int16
	Guid        int32
	UserId      int64
	Name        StringWithLen
	Type        int32
	LotteryId   int32
	LotteryType int32
	PropsId     int32
	Num         int32
	Coins       int32
	Metal       int32
	Gas         int32
	Money       int32
	BroFlag     int32
	LockFlag    int32
}

func NewRespGainLottery() *RespGainLottery {
	return &RespGainLottery{
		Name: StringWithLen{
			Length: int32(MaxName),
		},
	}
}

type ReqTechUpgradeInfo struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
}

func (c *ReqTechUpgradeInfo) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqTechUpgradeInfo(guid int32) *ReqTechUpgradeInfo {
	return &ReqTechUpgradeInfo{
		UsSize: int16(12),
		UsType: int16(ReqTechUpgradeInfoType),
		SeqId:  0,
		Guid:   guid,
	}
}
