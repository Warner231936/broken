package msg

type ReqPlayerInfo struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
	HdFlag int32
}

func (c *ReqPlayerInfo) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqPlayerInfo(guid, hdFlag int32) *ReqPlayerInfo {
	return &ReqPlayerInfo{
		UsSize: int16(16),
		UsType: int16(ReqPlayerInfoType),
		SeqId:  0,
		Guid:   guid,
		HdFlag: hdFlag,
	}
}

type RoleInfo struct {
	UsSize              int16
	UsType              int16
	GalaxyMapId         int32
	GalaxyId            int32
	ConsortiaId         int32
	PropsPack           int32
	PropsCorpsPack      int32
	ConsortiaJob        byte
	ConsortiaUnionlevel byte
	ConsortiaShopLevel  byte
	GameServerId        byte
	CommanderCard       int32
	CommanderCredit     int32
	CommanderCard2      int32
	CommanderCard3      int32
	CommanderCardUnion  int32
	ChargeFlag          int32
	AddPackMoney        int32
	LotteryCredit       int32
	ShipSpeedCredit     int32
	LotteryStatus       int32
	ConsortiaThrowValue int32
	ConsortiaUnionValue int32
	ConsortiaShopValue  int32
	Name                StringWithLen
	DefyEctypeNum       int32
	Badge               int32
	Honor               int32
	ServerTime          int32
	TollGate            int32
	Year                int16
	Month               byte
	Day                 byte
	NoviceGuide         int32
	WarScoreExchange    int32
}

func NewRoleInfo() *RoleInfo {
	return &RoleInfo{
		Name: StringWithLen{
			Length: int32(MaxName),
		},
	}
}

type ReqPlayerResource struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
}

func (c *ReqPlayerResource) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqPlayerResource(guid int32) *ReqPlayerResource {
	return &ReqPlayerResource{
		UsSize: int16(12),
		UsType: int16(ReqPlayerResourceType),
		SeqId:  0,
		Guid:   guid,
	}
}

type RespPlayerResource struct {
	UsSize        int16
	UsType        int16
	UserGas       int32
	UserMetal     int32
	UserMoney     int32
	Credit        int32
	Level         int32
	Exp           int32
	Coins         int32
	OutGas        int32
	OutMetal      int32
	OutMoney      int32
	MaxSpValue    int32
	SpValue       int32
	MoneyBuyNum   int32
	DefyEctypeNum int32
	MatchCount    int32
	TollGate      int32
	Reserve       int32
}

func NewRespPlayerResource() *RespPlayerResource {
	return &RespPlayerResource{}
}

type ReqStorageResource struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
}

func (c *ReqStorageResource) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqStorageResource(guid int32) *ReqStorageResource {
	return &ReqStorageResource{
		UsSize: int16(12),
		UsType: int16(ReqStorageResourceType),
		SeqId:  0,
		Guid:   guid,
	}
}
