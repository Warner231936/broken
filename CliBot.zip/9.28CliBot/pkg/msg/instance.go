package msg

type RespEcTypePass struct {
	UsSize  int16
	UsType  int16
	DataLen int32
	Data    []int32
}

func NewRespEcTypePass() *RespEcTypePass {
	return &RespEcTypePass{}
}
