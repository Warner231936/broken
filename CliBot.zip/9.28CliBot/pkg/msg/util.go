package msg

type StringWithLen struct {
	Length int32
	Value  string
}
