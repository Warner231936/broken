package msg

type ReqGetOnlineAward struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
}

func (c *ReqGetOnlineAward) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqGetOnlineAward(Guid int32) *ReqGetOnlineAward {
	return &ReqGetOnlineAward{
		UsSize: 12,
		UsType: int16(ReqGetOnlineAwardType),
		SeqId:  0,
		Guid:   Guid,
	}
}

type RespGetOnlineAward struct {
	UsSize    int16
	UsType    int16
	ErrorCode int32
	PropsId   int32
	PropsNum  int32
}

func NewRespGetOnlineAward() *RespGetOnlineAward {
	return &RespGetOnlineAward{}
}

type RespOnlineAward struct {
	UsSize    int16
	UsType    int16
	PropsId   int32
	PropsNum  int32
	SpareTime int32
}

func NewRespOnlineAward() *RespOnlineAward {
	return &RespOnlineAward{}
}
