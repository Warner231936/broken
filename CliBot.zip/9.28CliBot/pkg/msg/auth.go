package msg

type LoginServerValidate struct {
	UsSize       int16
	UsType       int16
	Port         int32
	UserId       int64
	Ip           StringWithLen
	CheckOutText StringWithLen
}

func NewLoginServerValidate() *LoginServerValidate {
	return &LoginServerValidate{
		Ip: StringWithLen{
			Length: int32(MaxName),
		},
		CheckOutText: StringWithLen{
			Length: int32(ValidateCodeLength),
		},
	}
}

type GameAuth struct {
	Ip           string
	Port         string
	CheckOutText string
	Username     string
}

func NewGameAuth(ip string, port string, checkOutText string, username string) *GameAuth {
	return &GameAuth{Ip: ip, Port: port, CheckOutText: checkOutText, Username: username}
}

type ClientLoginToL struct {
	UsSize       int16
	UsType       int16
	SeqId        int32
	UserId       int64
	SessionKey   StringWithLen
	GameServerId int32
	RegisterFlag int32
	RegisterName StringWithLen
}

func (c *ClientLoginToL) SetSeqId(i int32) {
	c.SeqId = i
}

func NewClientLoginToL(userId int64, sessionKey string) *ClientLoginToL {
	return &ClientLoginToL{
		UsSize:       184,
		UsType:       int16(ClientLogInToL),
		SeqId:        0,
		UserId:       userId,
		SessionKey:   StringWithLen{Length: int32(SessionKeyLength), Value: sessionKey},
		GameServerId: 0,
		RegisterFlag: 0,
		RegisterName: StringWithLen{Length: int32(MaxName), Value: ""},
	}
}

type ClientLoginToG struct {
	UsSize       int16
	UsType       int16
	SeqId        int32
	UserId       int64
	CheckoutText StringWithLen
	SessionKey   StringWithLen
	RegisterName StringWithLen
	RegisterFlag bool
}

func (c *ClientLoginToG) SetSeqId(i int32) {
	c.SeqId = i
}

func NewClientLoginToG(userId int64, checkoutText, sessionKey string) *ClientLoginToG {
	return &ClientLoginToG{
		UsSize:       int16(17 + ValidateCodeLength + SessionKeyLength + MaxName),
		UsType:       int16(ClientLogInToG),
		SeqId:        0,
		UserId:       userId,
		CheckoutText: StringWithLen{Length: int32(ValidateCodeLength), Value: checkoutText},
		SessionKey:   StringWithLen{Length: int32(SessionKeyLength), Value: sessionKey},
		RegisterName: StringWithLen{Length: int32(MaxName), Value: ""},
		RegisterFlag: false,
	}
}

type GameServerLoginResp struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
	HdFlag int32
}

func NewGameServerLoginResp() *GameServerLoginResp {
	return &GameServerLoginResp{}
}
