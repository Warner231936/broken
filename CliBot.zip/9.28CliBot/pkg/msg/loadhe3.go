package msg

type ReqLoadShipTeamAll struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
}

func NewReqLoadShipTeamAll(guid int32) *ReqLoadShipTeamAll {
	return &ReqLoadShipTeamAll{
		UsSize: int16(12),
		UsType: int16(ReqLoadShipTeamAllType),
		SeqId:  0,
		Guid:   guid,
	}
}

func (c *ReqLoadShipTeamAll) SetSeqId(i int32) {
	c.SeqId = i
}

type ShipTeamFuelInfo struct {
	ShipName   StringWithLen
	ShipTeamId int32
	ShipNum    int32
	ShipSpace  int32
	Gas        int32
	Supply     int32
}

func NewShipTeamFuelInfo() *ShipTeamFuelInfo {
	return &ShipTeamFuelInfo{
		ShipName: StringWithLen{
			Length: int32(MaxName),
		},
	}
}

type RespLoadShipTeamAll struct {
	UsSize  int16
	UsType  int16
	SeqId   int32
	Guid    int32
	DataLen int32
	Data    [19]ShipTeamFuelInfo
}

func NewRespLoadShipTeamAll() *RespLoadShipTeamAll {
	resp := RespLoadShipTeamAll{}
	for i := 0; i < len(resp.Data); i++ {
		resp.Data[i] = *NewShipTeamFuelInfo()
	}

	return &resp
}

type ReqLoadShipTeam struct {
	UsSize     int16
	UsType     int16
	SeqId      int32
	Guid       int32
	ShipTeamId int32
	Gas        int32
}

func (c *ReqLoadShipTeam) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqLoadShipTeam(guid int32, shipTeamId int32, gas int32) *ReqLoadShipTeam {
	return &ReqLoadShipTeam{
		UsSize:     int16(20),
		UsType:     int16(ReqLoadShipTeamType),
		SeqId:      0,
		Guid:       guid,
		ShipTeamId: shipTeamId,
		Gas:        gas,
	}
}

type RespLoadShipTeam struct {
	UsSize      int16
	UsType      int16
	GalaxyMapId int32
	GalaxyId    int32
	ShipTeamId  int32
	Gas         int32
}

func NewRespLoadShipTeam() *RespLoadShipTeam {
	return &RespLoadShipTeam{}
}
