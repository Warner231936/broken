package msg

type RespUnionCommanderCardBroadcast struct {
	UsSize      int16
	UsType      int16
	Guid        int32
	UserId      int64
	Name        StringWithLen
	SkillId     int32
	CardLevel   int32
	SuccessFlag int32
}

func NewRespUnionCommanderCardBroadcast() *RespUnionCommanderCardBroadcast {
	return &RespUnionCommanderCardBroadcast{
		Name: StringWithLen{
			Length: int32(MaxName),
		},
	}
}
