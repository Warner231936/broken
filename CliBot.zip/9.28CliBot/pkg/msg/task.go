package msg

type ReqTaskInfo struct {
	UsSize int16
	UsType int16
	SeqId  int32
	Guid   int32
}

func (c *ReqTaskInfo) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqTaskInfo(guid int32) *ReqTaskInfo {
	return &ReqTaskInfo{
		UsSize: 12,
		UsType: int16(ReqTaskInfoType),
		SeqId:  0,
		Guid:   guid,
	}
}
