package msg

type ReqJumpGalaxyShip struct {
	UsSize      int16
	UsType      int16
	SeqId       int32
	Guid        int32
	GalaxyMapId int32
	GalaxyId    int32
	Type        int32
}

func (c *ReqJumpGalaxyShip) SetSeqId(i int32) {
	c.SeqId = i
}

func NewReqJumpGalaxyShip(guid, galaxyMapId, galaxyId, typ int32) *ReqJumpGalaxyShip {
	return &ReqJumpGalaxyShip{
		UsSize:      int16(24),
		UsType:      int16(ReqJumpGalaxyShipType),
		SeqId:       0,
		Guid:        guid,
		GalaxyMapId: galaxyMapId,
		GalaxyId:    galaxyId,
		Type:        typ,
	}
}

type JumpGalaxyShip struct {
	TeamName     StringWithLen
	ShipTeamId   int32
	JumpNeedTime int32
	ShipNum      int32
	Gas          int32
	CommanderId  int32
	BodyId       int16
	GasPercent   int16
}

func NewJumpGalaxyShip() *JumpGalaxyShip {
	return &JumpGalaxyShip{
		TeamName: StringWithLen{
			Length: int32(MaxName),
		},
	}
}

type RespJumpGalaxyShip struct {
	UsSize      int16
	UsType      int16
	GalaxyId    int32
	DataLen     byte
	Type        byte
	GalaxyMapId byte
	JumpType    byte
	Data        [18]JumpGalaxyShip
}

func NewRespJumpGalaxyShip() *RespJumpGalaxyShip {
	res := RespJumpGalaxyShip{}
	for i := 0; i < len(res.Data); i++ {
		res.Data[i] = *NewJumpGalaxyShip()
	}
	return &res
}
