package msg

type RespMapBlock struct {
	UsSize     int16
	UsType     int16
	BlockCount int32
}

func NewRespMapBlock() *RespMapBlock {
	return &RespMapBlock{}
}
