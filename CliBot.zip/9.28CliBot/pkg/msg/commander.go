package msg

type CommanderBaseInfo struct {
	Name        StringWithLen
	UserId      int64
	CommanderId int32
	ShipTeamId  int32
	State       int32
	Skill       int16
	Level       byte
	Type        byte
}

func NewCommanderBaseInfo() *CommanderBaseInfo {
	return &CommanderBaseInfo{
		Name: StringWithLen{
			Length: int32(MaxName),
		},
	}
}

type RespCommanderBaseInfo struct {
	UsSize         int16
	UsType         int16
	DataLen        int32
	NextInviteTime int32
	Reserved       int32
	Data           [18]CommanderBaseInfo
}

func NewRespCommanderBaseInfo() *RespCommanderBaseInfo {
	res := RespCommanderBaseInfo{}
	for i := 0; i < len(res.Data); i++ {
		res.Data[i] = *NewCommanderBaseInfo()
	}
	return &res
}

type ReqCommanderInfo struct {
	UsSize      int16
	UsType      int16
	SeqId       int32
	Guid        int32
	CommanderId int32
	ShowType    int32
}

func NewReqCommanderInfo(guid, commanderId, showType int32) *ReqCommanderInfo {
	return &ReqCommanderInfo{
		UsSize:      int16(20),
		UsType:      int16(ReqCommanderInfoType),
		SeqId:       0,
		Guid:        guid,
		CommanderId: commanderId,
		ShowType:    showType,
	}
}

func (c *ReqCommanderInfo) SetSeqId(i int32) {
	c.SeqId = i
}

type ShipTeamNum struct {
	ShipModelId int32
	Num         int32
}

type CommanderInfo struct {
	CommanderId int32
	State       int32
}

type RespCommanderInfo struct {
	UsSize         int16
	UsType         int16
	CommanderId    int32
	ShipTeamId     int32
	RestTime       int32
	Exp            int32
	Aim            int16
	Blench         int16
	Priority       int16
	Electron       int16
	Skill          int16
	CardLevel      int16
	Level          byte
	State          byte
	ShowType       byte
	CommanderZJ    StringWithLen
	TeamBody       [9]ShipTeamNum
	Target         byte
	TargetInterval byte
	Reserve        byte
	AllStatusLen   byte
	AllStatus      [60]CommanderInfo
	Stone          [12]int16
	StoneHole      int32
	AimPer         byte
	BlenchPer      byte
	PriorityPer    byte
	ElectronPer    byte
	CmosExp        [5]int32
	Cmos           [5]int16
}

func NewRespCommanderInfo() *RespCommanderInfo {
	return &RespCommanderInfo{
		CommanderZJ: StringWithLen{
			Length: int32(CommanderZJCount),
		},
	}
}
