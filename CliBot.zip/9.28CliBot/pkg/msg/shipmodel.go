package msg

type RespShipCreatingComplete struct {
	UsSize  int16
	UsType  int16
	IndexId int32
}

func NewRespShipCreatingComplete() *RespShipCreatingComplete {
	return &RespShipCreatingComplete{}
}
