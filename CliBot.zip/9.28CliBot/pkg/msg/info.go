package msg

type RespCustomMoreInfo struct {
	UsSize       int16
	UsType       int16
	UserId       int64
	Guid         int32
	Kind         byte
	ProfileImage int32
}

func NewRespCustomMoreInfo() *RespCustomMoreInfo {
	return &RespCustomMoreInfo{}
}

type RespCustomConfiguration struct {
	UsSize       int16
	UsType       int16
	ResourcesUrl StringWithLen
}

func NewRespCustomConfiguration() *RespCustomConfiguration {
	return &RespCustomConfiguration{
		ResourcesUrl: StringWithLen{
			Length: int32(52),
		},
	}
}
