package auth

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
)

const ApiUri = "https://beta-api.supergo2.com"

type AuthResp struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    struct {
		Email     string `json:"email"`
		Username  string `json:"username"`
		Vip       int    `json:"vip"`
		Rank      string `json:"rank"`
		Token     string `json:"token"`
		MaxPlanet int    `json:"maxPlanet"`
	} `json:"data"`
}

type Auth struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func LoginLogin(username, password string) (authResp *AuthResp, err error) {
	auth := Auth{username, password}
	body, _ := json.Marshal(auth)
	client := &http.Client{}
	req, err := http.NewRequest("POST", fmt.Sprintf("%s/login/login/account", ApiUri), bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.Header.Add("User-Agent", `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.27 Safari/537.36`)

	if err != nil {
		return nil, err
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}

	err = json.NewDecoder(resp.Body).Decode(&authResp)
	if err != nil {
		return nil, err
	} else if authResp.Code != 200 {
		return nil, errors.New(authResp.Message)
	}

	return authResp, nil
}

func LoginGetPlanets(token string) (userPlanets UserPlanetsResp, err error) {
	client := &http.Client{}
	req, err := http.NewRequest("GET", fmt.Sprintf("%s/account/list/user", ApiUri), nil)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.Header.Add("User-Agent", `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.27 Safari/537.36`)
	req.Header.Add("authorization", token)

	if err != nil {
		return UserPlanetsResp{}, err
	}

	resp, err := client.Do(req)
	if err != nil {
		return UserPlanetsResp{}, err
	}

	var planetsResp UserPlanetsResp
	err = json.NewDecoder(resp.Body).Decode(&planetsResp)
	if err != nil {
		return UserPlanetsResp{}, err
	} else if planetsResp.Code != 200 {
		return UserPlanetsResp{}, errors.New(planetsResp.Message)
	}

	return planetsResp, nil
}

type LoginPlayResp struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    struct {
		SessionKey string `json:"sessionKey"`
		UserId     int    `json:"userId"`
	} `json:"data"`
}

type UserPlanetsResp struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    []struct {
		UserId    int    `json:"userId"`
		Username  string `json:"username"`
		Star      string `json:"star"`
		Ground    int    `json:"ground"`
		Resources struct {
			Gold           int    `json:"gold"`
			He3            int    `json:"he3"`
			Metal          int    `json:"metal"`
			Vouchers       int    `json:"vouchers"`
			MallPoints     int    `json:"mallPoints"`
			Coupons        int    `json:"coupons"`
			Corsairs       int    `json:"corsairs"`
			Honor          int    `json:"honor"`
			Badge          int    `json:"badge"`
			ChampionPoints int    `json:"championPoints"`
			FreeSpins      int    `json:"freeSpins"`
			LastSpinTime   string `json:"lastSpin"`
		} `json:"resources"`
	}
}

func LoginPlay(token string, userId int) (sessionKey string, err error) {
	client := &http.Client{}
	address := fmt.Sprintf("https://beta-api.supergo2.com/account/play/user/%d", userId)
	req, err := http.NewRequest("GET", address, nil)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.Header.Add("User-Agent", `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.27 Safari/537.36`)
	req.Header.Add("authorization", token)

	if err != nil {
		return "", err
	}

	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}

	var loginPlayResp LoginPlayResp
	err = json.NewDecoder(resp.Body).Decode(&loginPlayResp)
	if err != nil {
		return "", err
	} else if loginPlayResp.Code != 200 {
		return "", errors.New(loginPlayResp.Message)
	}

	return loginPlayResp.Data.SessionKey, nil
}
